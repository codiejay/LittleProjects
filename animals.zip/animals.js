const input = document.getElementById("inputMan");  //getting the input(slider)
const extraFigure = document.querySelector(".extrafigure"); //getting the span element repesenting the Extrafigur so i can edit it's innerHTML
const pricefigure = document.querySelector(".pricefigure");//getting the span element  repesenting the price so i can edit it's innerHTML
const planname  = document.querySelector(".planname");//getting the span element   repesenting the paln's name so i can edit it's innerHTML
const developer = document.querySelector(".developer") //kids stuff ;)
input.value = "20"
function getCurrentValue() //remeber this function was triggered in my html so here i create it
{
    if(input.value/20 == 1  )  ///getting the  first input value and changing all Values respectively
    {
       
           extraFigure.innerHTML = "0-4999";
           pricefigure.innerHTML = "25.99";
           planname.innerHTML = "Starter";

           extraFigure.style.color = 'rgba(128, 128, 128, 0.782)'; //from here i change the colors to draw users attention
           planname.style.color =   'rgba(128, 128, 128, 0.782)';
           pricefigure.style.color = " rgba(0, 0, 255, 0.789) " ;
    }
    if(input.value/40 == 1  )  //getting the second input value and changing all Values respectively
    {
       
           extraFigure.innerHTML = "5000-14,999";
           pricefigure.innerHTML = "49.99";
           planname.innerHTML = "Advance";

           extraFigure.style.color = 'rgba(128, 128, 128, 0.992)';
           planname.style.color =   'rgba(128, 128, 128, 0.992)';
           pricefigure.style.color = " rgba(0, 0, 255, 0.899) " ;
    }

    if(input.value/60 == 1  )  //getting the third input value and changing all Values respectively
    {
       
           extraFigure.innerHTML = "15,000-29,999";
           pricefigure.innerHTML = "99.99";
           planname.innerHTML = "Premiere";

           extraFigure.style.color = 'rgba(128, 128, 128, 1)';
           planname.style.color =   'rgba(128, 128, 128, 1)';
           pricefigure.style.color = " rgba(0, 0, 255, 1) " ;
    }

    if(input.value/80 == 1  )  //getting the  fourth input value and changing all Values respectively
    {
       
           extraFigure.innerHTML = "30000-50000";
           pricefigure.innerHTML = "149.99";
           planname.innerHTML = "Elite";

           extraFigure.style.color = 'rgba(128, 128, 128, 149)';
           planname.style.color =   'rgba(128, 128, 128, 194)';
           pricefigure.style.color = " rgba(0, 0, 255, 194) " ;
    }
    if(input.value/100 == 1  ) //getting the  fifth input value and changing all Values respectively
    {
       
           extraFigure.innerHTML = "50k +";
           pricefigure.innerHTML = "349.99";
           planname.innerHTML = "Supreme Pro";

           extraFigure.style.color = 'red'
           planname.style.color =   'blue';
           pricefigure.style.color = " red " ;
    }




    console.log(input.value);
    developer.innerHTML = input.value
}





